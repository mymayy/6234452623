/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_2;

/**
 *
 * @author USER
 */
public class MagicSquare {
    private final int size;
    private int[][] square;
    public MagicSquare(int n){
        size=n;
        square = new int[n][n];
        int i = n-1;
        int j = n/2;
        square[i][j]=1;
        for (int k=2;k<=n*n;k++){
            if(i+1>n-1 && j+1<=n-1){
                i=0;
                j++;
                square[i][j]=k;
            }
            else if(i+1<=n-1 && j+1>n-1){
                j=0;
                i++;
                square[i][j]=k;
            }
            else if(i+1>n-1 && j+1>n-1){
                i--;
                square[i][j]=k;
            }
            else if(square[i+1][j+1]!=0){
                i--;
                square[i][j]=k;
            }
            else{
                j++;
                i++;
                square[i][j]=k;
            }
        }
    }

    public String toString(){
        String s = "";
        for (int i=0;i<size;i++){
            for (int j=0;j<size;j++){
                s=s+"\t"+square[i][j];
            }
            s=s+"\n";
        }
        return s;
    }
}
