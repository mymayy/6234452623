/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

/**
 *
 * @author USER
 */
public class PurseTester {
    public static void main(String[] args) {
        Purse purse1 = new Purse();
        Purse purse2 = new Purse();
        purse1.addCoin("Quater");
        purse1.addCoin("Penny");
        purse1.addCoin("Dime");
        purse2.addCoin("Penny");
        purse2.addCoin("Quater");
        purse2.addCoin("Dime");
        purse1.reverse();
        //purse1.transfer(purse2);
        System.out.println(purse1.sameContents(purse2));
        System.out.println(purse1.sameCoins(purse2));
        System.out.println(purse1.toString());
        System.out.println(purse2.toString());
    }
}
