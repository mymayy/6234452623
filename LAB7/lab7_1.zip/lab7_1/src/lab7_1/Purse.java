/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

import java.util.ArrayList;

/**
 *
 * @author USER
 */
public class Purse {
    private ArrayList<String> purse = new ArrayList<String>() ;
    public void addCoin(String coinName){
       purse.add(coinName);
    }  
    public String toString(){
        return "Purse"+purse;
    }
    public ArrayList<String> reverse(){
        ArrayList<String> revPurse = new ArrayList<String>();
        for(int i=purse.size()-1;i<0;i--){
            revPurse.add(revPurse.get(i));
        }
        return revPurse;
    }
    public void transfer(Purse other){
        while(purse.size()>0){
            other.purse.add(purse.get(0));
            purse.remove(0);
        }
    }
    public boolean sameContents(Purse other){
        boolean result = true;
        if (purse.size()!=other.purse.size()){
            result = false;
        }
        else{
            for(int i=0;i<purse.size();i++){
                if (!purse.get(i).equals(other.purse.get(i))){
                    result = false;
                    break;
                }
            }
        }
        return result;
    }
    public boolean sameCoins(Purse other){
        int wallet1=0;
        int wallet2=0;
        if (purse.size()!=other.purse.size()){
            return false;
        }
        else{
            for(int i=0;i<purse.size();i++){
                switch(purse.get(i)){
                    case "Quarter":wallet1+=1;
                    case "Dime":wallet1+=1;
                    case "Nickel":wallet1+=1;
                    case "Penny":wallet1+=1;
                }
                switch(other.purse.get(i)){
                    case "Quarter":wallet2+=1;
                    case "Dime":wallet2+=1;
                    case "Nickel":wallet2+=1;
                    case "Penny":wallet2+=1;
                }
            }
        }
        return wallet1==wallet2;
    }
}
