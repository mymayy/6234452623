/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_3;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author USER
 */
public class FileMatch {
    public static void main(String[] args) {
        ArrayList<AccountRecord> acctList = new ArrayList<>();
        ArrayList<TransactionRecord> transList = new ArrayList<>();
        File mFile = new File("master.txt");
        File tFile = new File("trans.txt");
        try(Scanner mRead = new Scanner(mFile);
            Scanner tRead = new Scanner(tFile)){
            while(mRead.hasNextLine()){
                String line = mRead.nextLine();
                String[] data = line.split(" ");
                int acctNo=Integer.parseInt(data[0]);
                String name=data[1]+" "+data[2];
                double balance=Double.parseDouble(data[3]);
                acctList.add(new AccountRecord(acctNo, name, balance));
            }
            while(tRead.hasNextLine()){
                String line = tRead.nextLine();
                String[] data = line.split(" ");
                int acctNo=Integer.parseInt(data[0]);
                double trans=Double.parseDouble(data[1]);
                transList.add(new TransactionRecord(acctNo, trans));
            }
            for(AccountRecord acct : acctList){    
                for(TransactionRecord t : transList){
                    acct.combine(t);
                }
            }
        }catch (IOException e) {
            e.printStackTrace();
        }
        
        try (RandomAccessFile r = new RandomAccessFile("newMaster.dat", "rw")){
            for (AccountRecord acct : acctList) {
                r.writeInt(acct.getAcctNo());
                r.writeChar(' ');
                String name = acct.getName();
                for (int i=name.length(); i<30; i++) {
                    name += " ";
                }
                r.writeChars(name);
                r.writeChar(' ');
                r.writeDouble(acct.getBalance());
                r.writeChar(' ');
                r.writeInt(acct.getTransCnt());
                r.writeChar('\n');
            }
        }catch (IOException e) {
            e.printStackTrace();
        }
        
        int accCnt = 0;
        double balance = 0;
        int transCnt = 0;
        try (RandomAccessFile r = new RandomAccessFile("newMaster.dat", "r")) {
            while (r.getFilePointer() < r.length()) {
                accCnt++;
                r.seek(r.getFilePointer()+68);
                balance+=r.readDouble();
                r.seek(r.getFilePointer()+2);
                int t = r.readInt();
                if(t == 0)
                    transCnt++;
                r.seek(r.getFilePointer()+2);
            }
        }catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Total Account Record : " + accCnt);
        System.out.println("Total balance : " + balance);
        System.out.println("No transaction : " + transCnt + " account.");
    }
}
