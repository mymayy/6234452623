/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_3;

/**
 *
 * @author USER
 */
public class TransactionRecord {
    private int acctNo;
    private double trans;
    public TransactionRecord(int acctNo,double trans){
        this.acctNo = acctNo;
        this.trans = trans;
    }
    public double getAcctNo(){
        return acctNo;
    }
    public double getTrans(){
        return trans;
    }
}
