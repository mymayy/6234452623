/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author USER
 */
public class SequentialTextFile {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        File f = new File("input.txt");
        Scanner sc = new Scanner(System.in);
        PrintWriter write = new PrintWriter(f);
        String in = sc.nextLine();
        while(!in.equals("quit")){
            write.print(in+"\n");
            in = sc.nextLine();
        }
        write.close();
        Scanner read = new Scanner(f);
        int charCnt = 0;
        int wordCnt = 0;
        int lineCnt = 0;
        while(read.hasNextLine()){
            String line = read.nextLine();
            lineCnt++;
            String[] words = line.split(" ");
            wordCnt += words.length;
            charCnt += line.length();
        }
        System.out.println("Total characters : "+charCnt);
        System.out.println("Total  words : "+ wordCnt);
        System.out.println("Total lines : "+lineCnt);
    }
}
