/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_2;

/**
 *
 * @author USER
 */
public class expo extends Taylor {
    public expo(int k,double x){
        super(k,x);
    }
    public double getApprox(){
        double total=0;
        for(int n=0;n<=super.getIter();n++){
            total+=Math.pow(super.getValue(),n)/super.factorial(n);
        }
        return total;
    }
    public void printValue(){
        System.out.println("Value from Math.exp() is "+Math.exp(super.getValue())+".");
        System.out.println("Approximated value is "+getApprox()+".");
    }
    
}
