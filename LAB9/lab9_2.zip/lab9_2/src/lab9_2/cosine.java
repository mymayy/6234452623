/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_2;

/**
 *
 * @author USER
 */
public class cosine extends Taylor {
    public cosine(int k,double x){
        super(k,x);
    }
    public double getApprox(){
        double total=0;
        for(int n=0;n<=super.getIter();n++){
            total+=(Math.pow((-1),n)*Math.pow(super.getValue(),2*n))/(super.factorial(2*n));
        }
        return total;
    }
    public void printValue(){
        System.out.println("Value from Math.cos() is "+ Math.cos(super.getValue())+".");
        System.out.println("Approximated value is "+getApprox()+".");
    }
}
