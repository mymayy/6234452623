/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_1;

/**
 *
 * @author USER
 */
public class CannonBall {
    private double initV;
    private double simS;
    private double simT;
    public static final double g = 9.81;
    public CannonBall(double v){
        initV=v;
    }
    public void simulatedFlight(){
        double v=initV;
        double deltaT = 0.01;
        double time = 0;
        int n=1;
        while (v>0){
            simS=simS+(v*deltaT);
            simT=simT+deltaT;
            v=v-g*deltaT;
            time=time+1;
            if (time==100){
                System.out.printf("Distance on %d sec: %.3f%n", n,simS );
                time=0;
                n=n+1;
            }
        }
    }
    public double calculusFlight(double t){
        double s = (-0.5)*g*Math.pow(t, 2) + initV*t;
        System.out.printf("Final distance: %.3f Total time: %.2f%n" , simS,simT );
        return Math.round(s*1000)/1000.000;
    }
    public double getSimulatedTime(){
        return simT;
    }
    public double getSimulatedDistance(){
        return simS;
    }
}
