/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_1;

/**
 *
 * @author USER
 */
public class Subject implements Evaluation {
    private String subject;
    private int score[];
    public Subject(String subject,int score[]){
        this.subject=subject;
        this.score=score;
    }

    @Override
    public double evaluate() {
        int total=0;
        for(int i=0;i<score.length;i++){
            total+=score[i];
        }
        return total/score.length;
    }

    @Override
    public char grade(double evaluate) {
        if(evaluate>=70)
            return 'P';
        else
            return 'F';
    }
    public String toString(){
        return subject;
    }
}
