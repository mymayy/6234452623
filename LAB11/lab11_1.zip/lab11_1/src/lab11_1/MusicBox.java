/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;

import java.util.ArrayList;

/**
 *
 * @author USER
 */
public class MusicBox implements SimpleQueue {
    private ArrayList<String> music = new ArrayList<>();
    
    @Override
    public void enqueue(Object o) {
        String m = (String) o;
        music.add(m);
        System.out.println(m+" is added in queue");
    }

    @Override
    public void dequeue() {
        System.out.println("Now playing "+music.get(0));
        music.remove(0);
    }
    
}
