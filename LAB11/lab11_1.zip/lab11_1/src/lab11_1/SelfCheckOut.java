/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;

import java.util.ArrayList;

/**
 *
 * @author USER
 */
public class SelfCheckOut implements SimpleQueue {
    private ArrayList<Product> product = new ArrayList<>();
    private double total;
    
    @Override
    public void enqueue(Object o) {
        Product p = (Product) o;
        product.add(p);
        System.out.println(p.getName()+" is added in queue");
    }

    @Override
    public void dequeue() {
        total+=product.get(0).getPrice();
        product.remove(0);
    }
    public double getAmount(){
        return total;
    }
    
}
