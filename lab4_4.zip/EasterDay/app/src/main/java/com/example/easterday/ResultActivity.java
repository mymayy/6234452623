package com.example.easterday;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;


public class ResultActivity extends AppCompatActivity {

    TextView textResult;
    String month;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        textResult = findViewById(R.id.textViewResult);
        month = getIntent().getExtras().getString("monthResult");
        int date = getIntent().getExtras().getInt("dateResult");
        textResult.setText(month + " " + date);





    }
}