package com.example.easterday;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button btnSubmit;
    EditText year;
    String month;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSubmit = findViewById(R.id.button);
        btnSubmit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                year = findViewById(R.id.editText);
                int y = Integer.parseInt(year.getText().toString());
                int a = y%19;
                int b = y/100;
                int c = y%100;
                int d = b/4;
                int e = b%4;
                int g = (8*b+13)/25;
                int h = (19*a+b-d-g+15)%30;
                int j = c/4;
                int k = c%4;
                int m = (a+11*h)/319;
                int r = (2*e+2*j-k-h+m+32)%7;
                int n = (h-m+r+90)/25;
                int p = (h-m+r+n+19)%32;

                month = "";
                switch (n){
                    case 1 :
                        month = "January";break;
                    case 2 :
                        month = "February";break;
                    case 3 :
                        month = "March";break;
                    case 4 :
                        month = "April";break;
                    case 5 :
                        month = "May";break;
                    case 6 :
                        month = "June";break;
                    case 7 :
                        month = "July";break;
                    case 8 :
                        month = "August";break;
                    case 9 :
                        month = "September";break;
                    case 10 :
                        month = "October";break;
                    case 11 :
                        month = "November";break;
                    case 12 :
                        month = "December";break;
                }

                Intent intent = new Intent(getApplicationContext(),ResultActivity.class);
                intent.putExtra("monthResult",month);
                intent.putExtra("dateResult",p);
                startActivity(intent);
            }
        });

    }
}