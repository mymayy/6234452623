/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_2;

/**
 *
 * @author USER
 */
public class LineTester {
    public static void main(String[] args){
        Line I1 = new Line(0,2);
        Line I2 = new Line(2,1);
        System.out.println("Are the two lines equals?: "+I1.equals(I2));
        System.out.println("Are the two lines parallel?: "+I1.isParallel(I2));
        System.out.println("Do the two lines intersect?: "+I1.isIntersect(I2));
        if (I1.isIntersect(I2)){
            System.out.println(String.format("Point of intersection: %.2f,%.2f",I1.getIntersectionPoint(I2).getX(),I1.getIntersectionPoint(I2).getY()));
        }
    }
}
