/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

/**
 *
 * @author usci
 */
public class CashRegister {
    private double total;
    private double payment;
    private double tax;
    private double taxRate;
    public CashRegister(double taxRate){
        this.taxRate=(taxRate/100);
    }
    public void recordPurchase(double price){
        total=total+price;
    }
    public void recordTaxablePurchase(double price){
        total=total+price;
        tax=tax+(price*taxRate);
    }
    public void enterPayment(double pay){
        payment=payment+pay;
    } 
    public double getTotalTax(){
        return tax;
    }
    public double giveChange(){
        double change = payment - total - tax;
        total=0;
        payment=0;
        tax=0;
        return change;
    } 
}
