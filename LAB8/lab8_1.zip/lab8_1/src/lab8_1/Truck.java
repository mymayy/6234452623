/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_1;

/**
 *
 * @author USER
 */
public class Truck extends Car{
    private double M_weight;
    private double weight;
    public Truck(double gas, double efficiency, double M_weight, double weight) {
        super(gas, efficiency);
        this.M_weight=M_weight;
        if (weight>M_weight)
            this.weight=M_weight;
        else
            this.weight=weight;
    }
    public void drive(double distance){
        double use=distance/super.getEfficiency();
        if (weight<1)
            use=use;
        else if (weight<=10)
            use+=use*0.1;
        else if (weight<=20)
            use+=use*0.2;
        else if (weight>20)
            use+=use*0.3;
        
        if (use>super.getGas())
            System.out.println("You cannot drive too far, plese add gas");
        else
            super.setGas(super.getGas()-use);
    }
}
