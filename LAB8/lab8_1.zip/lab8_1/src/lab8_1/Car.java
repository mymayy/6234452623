/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_1;

/**
 *
 * @author USER
 */
public class Car {
    private double gas;
    private double efficiency;
    public Car(double gas,double efficiency){
        this.gas=gas;
        this.efficiency=efficiency;
    }
    public void drive(double distance){
        double use=distance/efficiency;
        if (use>gas)
            System.out.println("You cannot drive too far, plese add gas");
        else
            gas-=use;   
    }
    public void setGas(double amount){
        gas=amount;
    }
    public double getGas(){
        return gas;
    }
    public double getEfficiency(){
        return efficiency;
    }
    public void addGas(double amount){
        gas+=amount;
    }
}